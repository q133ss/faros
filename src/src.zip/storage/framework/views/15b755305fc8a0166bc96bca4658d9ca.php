<nav class="mobilemenu mobMenuContainer custom-scroll" id="menu">
    <div class="mobilemenu__wrapMenu">
        <div class="mobilemenu__wrapMenu__menu">
            <a href="/#form" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/start.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">Начать проект</span>
            </a>
            <a href="<?php echo e(route('articles.index')); ?>" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/blogs.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">Статьи</span>
            </a>
            <a href="<?php echo e(route('service.index')); ?>" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/services.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">Услуги</span>
            </a>
            <a href="<?php echo e(route('smi.index')); ?>" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/media.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">СМИ</span>
            </a>
            <a href="<?php echo e(route('case.index')); ?>" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/keyses.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">Кейсы</span>
            </a>
            <a href="<?php echo e(route('video.index')); ?>" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/videos.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">Мы в эфире</span>
            </a>
            <a href="<?php echo e(route('team.index')); ?>" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/teams.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">Команда</span>
            </a>
            <a href="<?php echo e(route('team.index')); ?>" class="mobilemenu__wrapMenu__menu__link">
                <img src="/images/min/icons/onlinepay.svg" alt="" class="mobilemenu__wrapMenu__menu__link__ico">
                <span class="mobilemenu__wrapMenu__menu__link__text">Online-оплата</span>
            </a>
        </div>
    </div>

    <div class="mobilemenu__footer">
        <div class="mobilemenu__footer__left">
            <a href="tel:88006008613" class="mobilemenu__footer__left__item">8 800 600 86 13</a>
            <div class="mobilemenu__footer__left__br"></div>
            <a href="mailto:a@a.aa" class="mobilemenu__footer__left__item">info@faros.media</a>
        </div>

        <div class="mobilemenu__footer__right">
            <a href="/" class="mobilemenu__footer__right__icoWrap">
                <img src="/images/min/icons/vk.svg" alt="" class="mobilemenu__footer__right__icoWrap__ico">
            </a>

            <!--<a href="#" class="mobilemenu__footer__right__icoWrap">
                <img src="/images/min/icons/fb.svg" alt="" class="mobilemenu__footer__right__icoWrap__ico">
            </a>-->

            <!--<a href="#" class="mobilemenu__footer__right__icoWrap">
                <img src="/images/min/icons/tw.svg" alt="" class="mobilemenu__footer__right__icoWrap__ico">
            </a>-->

            <a href="/" class="mobilemenu__footer__right__icoWrap">
                <img src="/images/min/icons/tg.svg" alt="" class="mobilemenu__footer__right__icoWrap__ico">
            </a>
        </div>
    </div>
</nav>
<?php /**PATH D:\OSPanel\home\faros.local\src\resources\views/inc/mobmenu.blade.php ENDPATH**/ ?>