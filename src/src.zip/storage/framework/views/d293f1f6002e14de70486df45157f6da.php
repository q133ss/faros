<?php $__env->startSection('title', 'Агентство по управлению репутацией и восприятием брендов Faros.Media сотрудники, команда'); ?>
<?php $__env->startSection('content'); ?>
    <div class="fullHeightBigDarkBlock _bgBlack6 _first fullHeightBigDarkBlock_teamFirst">
        <h1 class="fullHeightBigDarkBlock__title fullHeightBigDarkBlock__title_team _colorWhite"><span
                class="_colorYellow">Faros.Media</span> - команда профессионалов в сфере управления восприятия
            бренда</h1>


        <p class="fullHeightBigDarkBlock__subtitle _colorWhite">Мы знаем как достичь эффективности при продвижении
            Ваших
            проектов.</p>

        <picture class="fullHeightBigDarkBlock__pic fullHeightBigDarkBlock__pic_team">
            <source type="image/webp" srcset="/images/min/team/teamBG.webp" media="(min-width: 769px)">
            <source type="image/webp" srcset="/images/min/team/teamBG_small.webp">
            <img srcset="../images/min/team/teamBG_small.png 320w, ../images/min/team/teamBG.png 768w" src="../images/min/team/teamBG.png">

        </picture>
    </div>

    <div class="team">
        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $counter++; ?>
        <div class="team__item">
            <?php if($counter == 1): ?>
            <picture class="team__item__imgSecondWrap">
                <img class="team__item__imgSecondWrap__img" src="/upload/iblock/pencil.png">
            </picture>
            <?php endif; ?>
            <picture class="team__item__pic">
                <img src="<?php echo e($team->img); ?>">
            </picture>

            <div class="team__item__data">
                <div class="team__item__data__peop">
                    <?php if($team->has_detail == true): ?>
                    <a href="<?php echo e(route('team.show', $team->slug)); ?>" class="team__item__data__peop__name"><?php echo e($team->name); ?></a>
                    <?php else: ?>
                    <p class="team__item__data__peop__name"><?php echo e($team->name); ?></p>
                    <?php endif; ?>
                    <p class="team__item__data__peop__post"><?php echo e($team->list_post); ?></p>
                </div>

                <p class="team__item__data__descr"><?php echo $team->list_text; ?></p>

                <div class="team__item__data__soc">
                    <?php if($team->instagram): ?>
                        <!--noindex--><a  href="<?php echo e($team->instagram); ?>"  target="_blank"
                                          class="team__item__data__soc__link" rel="nofollow">
                            <img src="../images/min/team/insta.svg" class="team__item__data__soc__ico">
                        </a><!--/noindex-->
                    <?php endif; ?>
                    <?php if($team->email): ?>
                    <a href="mailto:<?php echo e($team->email); ?>" class="team__item__data__soc__link">
                        <img src="../images/min/team/mail.svg" class="team__item__data__soc__ico">
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="grow-full"></div>
            <?php if($counter == 2): ?>
                <picture class="team__item__imgFirstWrap">
                    <img class="team__item__imgFirstWrap__img" src="/upload/iblock/star.webp">
                </picture>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\home\faros.local\src\resources\views/team/index.blade.php ENDPATH**/ ?>